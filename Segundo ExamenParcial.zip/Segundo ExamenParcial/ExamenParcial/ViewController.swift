//
//  ViewController.swift
//  ExamenParcial
//
//  Created by 2020-1 on 9/20/19.
//  Copyright © 2019 UltraCode. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var Switch1: UISwitch!
    @IBOutlet weak var Switch2: UISwitch!
    @IBOutlet weak var Switch3: UISwitch!
    @IBOutlet weak var Switch4: UISwitch!
    @IBOutlet weak var Switch5: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func revisarButton(_ sender: Any) {
        if Switch1.isOn == false && Switch2.isOn == true && Switch3.isOn == true && Switch4.isOn == true && Switch5.isOn == false {
            performSegue(withIdentifier: "felicidades", sender: sender)
        }
        else{
            performSegue(withIdentifier: "error", sender: sender)
        }
    }
    
}

